<?php if ( ! defined('ABSPATH')) exit('restricted access'); ?>
<div id="sidebar-nav">
    <ul class="clearfix">
    	<?php _option_menu() ?>

    </ul>
</div>
<div class="sam-saving-info"><?php echo _e('Please save your changes by clicking save button at the bottom', 'sampression'); ?></div>