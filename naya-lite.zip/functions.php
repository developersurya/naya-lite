<?php
/**
 * Default function file
 * @package sampression framework v 1.0
 * @theme naya 1.0
 */
if ( ! defined( 'ABSPATH' ) ) exit( 'restricted access' );

require_once( dirname( __FILE__ ) . '/inc/init.php' ); 